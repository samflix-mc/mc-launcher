An inline callout for a state the player must read: the splash cannot reach the server, a setting is risky, maintenance is scheduled.

## Provide
- `.hm-alert` + `--danger`, `--warning`, `--info` or `--success`, holding a 20px `.hm-alert__icon`, `.hm-alert__title`, `.hm-alert__text` and optionally `.hm-alert__actions` (small buttons: one primary at most, then ghost, or a caption such as the retry countdown).
- `role="alert"` on danger alerts that appear after an action; `role="status"` otherwise.
- The rim of a toned alert takes the tone's colour (bundle.css `::after`), so it reads as tinted glass, not a coloured box.

## Rules
- The title says what happened in five words; the text says what to do. "Can't reach the server" / "Check your network, then try again."
- The splash error state is exactly this component with `--danger`, a Try again primary and the auto-retry countdown beside it. There is no offline mode.
- Never stack two alerts; merge them or move the second into a status badge.
