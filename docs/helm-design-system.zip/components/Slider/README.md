A range input with a live value: the memory allocation, and anything else with a sensible minimum and maximum.

## Provide
- `.hm-slider` with `.hm-slider__row` (label left, `.hm-slider__value` right, mono), the `<input type="range" class="hm-range">` and `.hm-slider__ticks` (min, recommended, max).
- Keep `--p` on the input equal to `(value − min) / (max − min)` in percent so the gold fill matches the thumb (Angular: `[style.--p]`).

## Rules
- Steps are whole units (1 GB); the value reads "6 GB", never "6144 MB".
- Show a `warning` note under the row when the value exceeds what the machine has minus 2 GB; never clamp silently.
- One slider per row; keyboard arrows move one step.
