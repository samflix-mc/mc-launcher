The signed-in player at the bottom right of the main window: head render in a circle, name, account state, and a chevron that opens the account menu.

## Provide
- `<button class="hm-player">` with `.hm-player__head` (a 40px circle holding an `<img>`, `object-fit: cover`, `image-rendering: pixelated`), `.hm-player__text` (`.hm-player__name`, `.hm-player__state`) and a 16px `chevron-down` icon with class `hm-player__chevron`.
- The head image: a 3D head render fetched by UUID from a skin render service — for example `https://visage.surgeplay.com/bust/64/<uuid>` (bust) or `https://mc-heads.net/head/<uuid>/64` (isometric head) — cached on disk by the launcher so the badge renders offline. Load it lazily; until it arrives, show the neutral cube placeholder the preview uses (no face, no character).
- States: default (signed in, `success` dot), `--signed-out` (name "Guest", state "Not signed in", neutral dot; clicking opens the auth window), `--offline` (session expired, `danger` dot; clicking re-runs sign-in).

## Rules
- The head sits in a circle concentric with the pill (pill radius 24, head radius 20, 4px inset): nothing square pokes out of the glass.
- Names are the Minecraft profile name, never the Microsoft account; truncate at 160px with an ellipsis.
- The menu it opens is `.hm-menu` (opaque), anchored above the badge: Profile, Refresh session, Switch account, Sign out.
- Do not show the UUID, email or token anywhere in the UI.
