The surface primitive every panel, card, dialog and toast is built on: translucent dark glass with a diagonal face, a specular in the top-left, a 1px rim that catches light, and the artwork blurred and saturated behind it.

## The recipe (bundle.css, `.hm-glass` and friends)
1. Base: `glass-dark` (bg at 46%) — `--glass-base`, the one knob. Dialogs, toasts and `--strong` use `glass-dark-strong` (62%).
2. Face: `--glass-face`, a 135° gradient from white 13% to 0 to white 5% — the sheet's own thickness.
3. Specular: `::before`, a radial white 16% in the top-left corner — where the light hits.
4. Rim: `::after`, a 1px masked gradient border from `glass-sheen` (top-left) through `glass-line` to a fainter catch at the bottom-right — the refraction edge that makes it read as glass.
5. Behind: `backdrop-filter: blur(blur-md) saturate(glass-saturate)`; one soft drop, `shadow-glass`.
The pseudo-elements sit at `z-index: -1` inside an isolated stacking context, so content always paints above them.

## Provide
- `.hm-glass` on a block; add `--pad` (20px) or `--pad-sm` (16px), or pad it yourself.
- Optional `.hm-glass__eyebrow` (uppercase `label`) and `.hm-glass__title` (`display-md`, pixel face) at the top.

## Variants
- `--strong`: denser base and `blur-lg` — anything that must read whatever is behind it.
- `--gold`: `gold-soft` tint and a gold rim — the one pinned or selected thing on a page. Never two per screen.
- `--light`: half the base — chips and controls that sit on another glass panel.
- `--interactive`: hover lifts 2px, deepens the shadow and brightens the specular; use on cards that open something (news cards).

## Rules
- Glass needs something behind it: the stage's artwork or the fallback gradient. Over a flat colour the blur does nothing and the sheet reads as a grey box — that is the artwork's job, not the glass's.
- Never stack dark glass on dark glass more than two deep; controls on a panel use light glass (`.hm-btn`, `.hm-status`, `.hm-tag`), which is `glass` + an inset top catch-light, no blur stack.
- Text on glass: `ink`, `ink-2`, `ink-3` only; status colours as text only at `body` size or larger. On a bright artwork raise `--glass-base` to bg at 60% on the window root rather than darkening the text.
- Opaque things (menus, tooltips) are not glass: `bg-overlay` and `.hm-menu`.
- A full-window frosted sheet is `.hm-pane` (the sign-in window): `glass-dark-strong` + `blur-lg`, edge to edge, under the titlebar and the content.
