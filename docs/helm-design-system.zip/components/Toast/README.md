A transient notice in the bottom-left corner of the main window: what just happened, one line of detail, at most two small actions; a progress toast stays until the job ends.

## Provide
- One `.hm-toasts` container per window (absolute, bottom-left, stacking upward); each `.hm-toast` + a tone (`--success`, `--danger`, `--info`, `--warning`, `--progress`) holding a 20px `.hm-toast__icon`, `.hm-toast__title`, a ghost icon `.hm-toast__close`, `.hm-toast__text`, optional `.hm-toast__actions` (`.hm-btn--sm`) and, for `--progress`, `.hm-toast__progress` wrapping an `.hm-progress`.
- `role="status"`; danger toasts that need a decision get `role="alert"` and no auto-dismiss.
- Timing: success and info dismiss after 6 s (hover pauses), danger and warning after 12 s or on action, progress when the job ends (it then turns into a success or danger toast in place). Newest at the bottom, at most three visible; older ones collapse into the notification center.
- Every toast is also written to the NotificationCenter, so nothing is lost when it fades.

## When it is a toast and when it is not
- Toast: a job finished or failed (download, verification, launcher update ready), a session event (signed in, session expired), a server event received while the window is open (maintenance in 10 minutes).
- Not a toast: validation of a field (the field's hint), a state the play button already shows (installing), a setting saved (nothing — it just applies).
- While the launcher is hidden or minimized (the game is running), the same events go to the OS through `@tauri-apps/plugin-notification`; the setting "Notifications: Launcher and system / Launcher only / Off" decides.

## Rules
- Title = what happened, in five words; text = the number or the next step. No "Success!".
- One primary action at most ("Retry", "Restart now"); the second is ghost.
- Never a toast on top of a dialog: queue it until the dialog closes.
