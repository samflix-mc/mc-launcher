The one big action at the bottom centre of Spawn; its label and state come from the launcher's status, never from the user.

## Provide
- `.hm-playbar` wrapping a `.hm-playbar__hint` (`caption`, what the button will do and why; `--danger` when the reason is a fault) and the `.hm-play` button.
- Inside `.hm-play`: a 22px icon, `.hm-play__label`, and optionally `.hm-play__meta` (size, percentage, speed).
- States, one class each:
  - default (no modifier) with label **Install** (`download`) when the modpack is missing, **Play** (`play`) when everything is ready, **Update & play** (`refresh-cw`) when a newer modpack exists;
  - `--busy` + `aria-busy="true"` while downloading, verifying or launching: add `.hm-play__fill` as the first child with `--p` set to the progress (`style="--p:42%"`), or `.hm-play__fill--indeterminate` while the size is unknown; label **Installing**, **Verifying**, **Launching**;
  - `--disabled` + `aria-disabled="true"` when the action is impossible. The label stays what it would be (Play or Install) so the player knows what is blocked; the hint says why: "No connection · retrying in 12 s", "Server in maintenance until 18:00", "Sign in to play".

## Rules
- There is no offline play: the launcher exists to join one server. No connection means the play and install buttons are `--disabled` with the network hint, and the launcher retries on its own.
- Label the action, not the state: "Play", not "Ready". The state lives in the hint and the status badges.
- The gold face is the accent at full strength; nothing else on Spawn is a gold fill (badges use `gold-soft`).
- Keep 264px minimum width so the label does not move between states; height 56px, `radius-xl`.
- Clicking while `--busy` does nothing; offer Cancel as a `.hm-btn--ghost` in the hint row if a download can be aborted.
