A 6px pill track with a gold fill, optionally labelled with what is happening and how far along it is.

## Provide
- `.hm-progress` containing an optional `.hm-progress__row` (left: the current step in `caption`; right: `.hm-progress__value` in the mono face — percent, count or size) and `.hm-progress__track` > `.hm-progress__fill` with `--p` as a percentage.
- `.hm-progress__fill--indeterminate` while the total is unknown (manifest fetch, DNS).
- `--lg` for an 8px track (the splash), `--success` when done, `--danger` when it failed (keep the value: "12/58").
- Add `role="progressbar"` with `aria-valuenow/min/max` or `aria-busy` on the element when the bar carries the only feedback.

## Rules
- One bar per operation. Several files download at once? Show the aggregate here and the per-file list elsewhere.
- Values are tabular mono so they do not jitter.
