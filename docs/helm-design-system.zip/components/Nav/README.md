The floating pill at the top centre of the main window with the three sections: Spawn, News, Settings. Spawn is always the landing page.

## Provide
- `<nav class="hm-nav" aria-label="Sections">` with three `.hm-nav__item` buttons (or `routerLink` anchors), each an icon (20px) plus the label; the current one gets `aria-current="page"`.
- Optional `.hm-nav__badge` after the News label with the unread count; drop it once the News page has been opened.

## Rules
- Three items, in that order, always visible. Adding a fourth section? Ask whether it belongs in Settings first.
- The active item is a lighter glass pill with a gold icon; the label stays `ink`.
- Nothing else sits on the nav row. The titlebar is above it, the page below.
