The landing page of the main window: the pinned news tile, the server and modpack status panels, the play button at the bottom centre and the player badge at the bottom right.

## Layout (1024×640 window, larger scales the same)
- `.hm-window` > `.hm-stage` (artwork + scrim) + `.hm-titlebar` (brand · server name · bell) + `.hm-page` with three rows: the `.hm-nav` centred; a two-column grid (the pinned `.hm-news--pinned` tile at 1.25fr, stretched to the height of the column beside it, then two stacked `.hm-glass` panels: Server with a status badge, address and ping; Modpack with version, mod count, loader and last verification); the bottom bar, a 1fr / auto / 1fr grid: empty, `.hm-playbar`, `.hm-player`.
- The middle of the page is left empty on purpose: it is where the server's artwork shows through. Do not fill it. Toasts stack in the bottom-left corner when they appear.

## Rules
- Spawn is what every launch opens on; the nav remembers nothing.
- The play button's state is derived from server status + modpack status + session, in that priority: no connection → disabled with the retry hint; server offline or in maintenance → disabled with the reason; not signed in → disabled with "Sign in to play"; modpack missing → Install; update available → Update & play; else Play. Play always verifies the installed files first (the `--busy` "Verifying" state) before launching.
- Status panels poll every 30 s; the badge switches to `--unknown` only before the first answer, never during a refresh.
- The pinned tile opens its item in the browser like every news tile.
- The artwork is per server: `background-image` on `.hm-stage__art`, from the server manifest, cached; while it loads, `--fallback` draws the abstract gradient. The previews use Mojang's public "Wilderness Bound" key art from `assets/Artwork`.
