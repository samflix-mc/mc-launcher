A ring that spins for anything shorter than a progress bar deserves: a status check, a session refresh, a menu action.

## Provide
- `<span class="hm-spinner" aria-hidden="true">` next to the text that says what is loading; sizes `--sm` (16) inline with `caption`, default 20, `--lg` (32) alone in an empty panel.
- `--ink` when it sits on a gold fill.

## Rules
- Never a spinner alone for more than two seconds: pair it with text, or switch to a progress bar.
- On buttons use `aria-busy` on the button instead of inserting a spinner.
