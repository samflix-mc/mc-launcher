The Microsoft sign-in flow in three steps — start, device code, done — shown in its own small window after the splash when no session is stored.

## Provide
- `.hm-dialog` > `.hm-auth` with `.hm-auth__steps` (three `.hm-auth__step`, `--done` as they complete), a `.hm-dialog__title` + `.hm-dialog__text`, then the step content:
  1. **Sign in to play**: the `.hm-btn--microsoft --lg --block` button and a hint "Opens your browser · takes about a minute".
  2. **Enter this code**: the device code in `.hm-code` (mono, letter-spaced, `user-select: all`) with a copy icon button; a `.hm-auth__wait` row with a spinner, "Waiting for Microsoft…" and the code's remaining lifetime in mono; a block secondary button that reopens the verification URL.
  3. **Signed in**: `.hm-auth__done` with the check icon, the head placeholder or render, the profile name and "Java Edition · verified".
- Errors (code expired, account owns no Minecraft, network) replace the step content with an `.hm-alert--danger` and a Try again primary; the steps bar stays.

## The window
- The dialog lives in its own Tauri window (see the AuthWindow page): 440×520, `resizable: false`, `maximizable: false`, `decorations: false`, centred on the main window; it carries a `.hm-titlebar--dialog --glass` so it can be moved, minimized and closed. Closing it quits the launcher if there is no stored session (say so in the titlebar title: "Sign in").
- On the OAuth callback (device-code poll succeeds) show step 3 for 1.2 s, then close the window and open the main window on Spawn.

## Rules
- Use Microsoft's official logo from their "Sign in with Microsoft" branding kit on the button, dropped into `assets/Logos`; the system does not draw it.
- Never ask for a password or email inside the launcher; the browser does that.
- The code well is the only place `code-lg` is used.
