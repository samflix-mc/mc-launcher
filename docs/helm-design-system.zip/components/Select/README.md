A native `<select>` restyled: field fill, control border, a chevron, options on `bg-overlay`.

## Provide
- `<select class="hm-select">` inside a `.hm-field` with a label; `--auto` for a natural width in a setting row (160px minimum).
- Options are short noun phrases; the current value is what the launcher does, not "Choose…".

## Rules
- Native on purpose: keyboard, screen readers and the OS popup come for free in a WebView; do not replace it with a custom listbox unless you need icons in the options.
- Five options or fewer; more than that is a search, not a select.
