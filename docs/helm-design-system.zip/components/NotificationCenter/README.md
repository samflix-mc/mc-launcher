The panel the titlebar bell opens: every notice the launcher produced, unread first, with the same tones as toasts.

## Provide
- `.hm-notif` (glass, 360px, anchored under the bell at the top-right) with `.hm-notif__head` (title "Notifications" + a ghost "Mark all read"), `.hm-notif__list` (scrolls after ~400px) of `.hm-notif__item` buttons, and `.hm-notif__foot` with a ghost "Clear all".
- Each item: `.hm-notif__dot` (gold when `--unread`), a 20px `.hm-notif__icon` coloured by tone (`--success`, `--danger`, `--info`, `--gold` for updates), `.hm-notif__body` (`.hm-notif__item-title`, `.hm-notif__text`), `.hm-notif__time` (relative under 24 h, then the date).
- The bell's `.hm-bell__count` is the unread count; opening the panel does not clear it — reading an item (click) or "Mark all read" does. `.hm-notif__empty` when there is nothing: "Nothing yet".
- Clicking an item performs its action when it has one (open News item, update from the play button, retry) and marks it read.

## Rules
- Persist the list on disk (last 50), so a restart keeps what the player missed while the game ran.
- Group nothing; newest first; a repeated event (three failed retries) updates the existing item's text and time instead of adding rows.
- Close on outside click and Escape; return focus to the bell.
