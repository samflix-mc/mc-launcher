The settings section: a left rail with the title and two group links, and a scrolling column of setting groups — Launcher first, Minecraft second.

## Layout
- `.hm-settings`: the rail (`display-lg` "Settings", links with icons, the version footer in mono) and `.hm-settings__body` with the two `.hm-settings-group`s; the rail links scroll to the group and mark the one in view with `aria-current="true"`.
- No play button here: the bottom bar is dropped, the body takes the height.

## Rules
- Changes apply as they are made; a `--warning` status badge "Config changed" appears next to the modpack on Spawn if a change (memory, Java) takes effect at the next launch.
- Paths are shown as the OS shows them (backslashes on Windows) in the mono face.
- Reset to defaults lives at the bottom of the Minecraft group as a `.hm-btn--danger --sm` with a confirmation dialog.
