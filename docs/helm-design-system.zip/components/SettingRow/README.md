The settings page's building block: a glass group with a heading, then rows with a label, a one-line description and the control at the right.

## Provide
- `<section class="hm-glass hm-settings-group">` > `.hm-settings-group__head` (`.hm-settings-group__title`, `.hm-settings-group__desc`) then any number of `.hm-setting` rows.
- Each row: a block with `.hm-setting__label` and optional `.hm-setting__desc`, then `.hm-setting__control` holding the control (switch, select, buttons, number inputs). `--stack` puts the control on its own line below (paths, sliders, text areas). `.hm-setting__note` adds a warning line across the row.
- The page: `.hm-settings` = a 200px `.hm-settings__nav` (the `display-lg` title, `.hm-settings__link`s with `aria-current="true"`, a mono version footer) and a scrolling `.hm-settings__body`.

## The two groups
- **Launcher**: Install location (path), After launching the game (select: Hide the launcher / Minimize to tray / Keep it open), Notifications (select: Launcher and system / Launcher only / Off), Keep game logs (switch + Open folder), Check for launcher updates (button + last-checked). Add Language and Close to tray here when they exist.
- **Minecraft**: Memory (slider with machine total and modpack recommendation), Window size (two number inputs), Fullscreen (switch), Java runtime (select: Bundled / System / Custom path), Extra JVM arguments (mono text).

## Rules
- Every change saves on its own; there is no Save button. Confirm only destructive ones (Reset settings) with a dialog.
- Descriptions state facts the player needs to decide ("This machine has 16 GB"), not what the control is.
- Keep rows 56px or taller so switches and selects line up across a group.
