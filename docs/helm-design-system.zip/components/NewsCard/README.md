A news item is a tile: the picture fills it, a scrim rises from the bottom, the tag, date and title sit on the scrim; clicking it opens the item on the server's website in the browser, and the arrow in the corner says so.

## Provide
- `<a class="hm-glass hm-glass--interactive hm-news" href="<item url>">` with, in order: `.hm-news__media` (the item's `image` as `background-image`; `--ph` draws the placeholder gradient when there is none), `.hm-news__scrim`, `.hm-news__open` (the `arrow-up-right` icon in a small light-glass square, always visible — the launcher is used with a mouse and the arrow is the promise that the tile leaves the app; the featured tile labels it: "Read on corsair-isles.net"), then `.hm-news__body` > `.hm-news__meta` (a `.hm-tag` and the date), `.hm-news__title`, optional `.hm-news__excerpt`.
- In Angular the anchor's click calls `open(url)` from `@tauri-apps/plugin-shell` (or `plugin-opener`) and prevents the default; keep `href` so middle-click and the status bar behave.
- Variants: default (16:9 tile, title two lines max, no excerpt), `--featured` (200px tall, full width at the top of News; pixel title 26px, excerpt, side scrim so the picture stays visible at the right), `--pinned` (Spawn: sized by its grid cell, gold rim via `hm-glass--gold`, pixel title 22px, excerpt), `--row` (128px thumbnail + one-line title; for lists and search results).
- Tags: `.hm-tag` (neutral), `--info` (update), `--success` (event), `--danger` (incident), `--gold` (pinned only).
- Layout: `.hm-news-grid` (auto-fill, 260px minimum; three columns at 1024) on the News page.
- Dates: `MMM d, yyyy` in English.

## Rules
- The picture is the card; text never sits beside it. Titles two lines at most (one on rows), sentence case, no final period; the excerpt only on featured and pinned.
- Images are 16:9, at least 800×450, JPEG or WebP; the scrim guarantees the text (ink on bg 90% at the bottom edge) whatever the picture. The previews use seeded picsum.photos photos from `assets/Demo` as stand-ins.
- Hover lifts the tile 2px, zooms the picture 3% over 360ms and brightens the arrow's square; `prefers-reduced-motion` drops the zoom.
- Exactly one pinned item, chosen by the server manifest; if none is pinned, the newest item takes the featured and pinned slots without the gold tag and rim.
