Single-line inputs: text, a path with a Browse button, a number with a unit, and the invalid state.

## Provide
- `<label class="hm-field">` with `.hm-field__label`, the `.hm-input`, and optionally `.hm-field__hint`; `--invalid` on the field turns the border and hint `danger`.
- Paths: `.hm-input-group` = `.hm-input.hm-input--mono` + a `.hm-btn` "Browse" that opens Tauri's dialog and writes the result back. Show the free space in the hint.
- Numbers: `.hm-input-unit` = `.hm-input.hm-input--num` (96px, right-aligned, tabular) + `.hm-input-unit__suffix` ("px", "GB").
- Focus: gold border with a `gold-soft` halo; `spellcheck="false"` on paths and addresses.

## Rules
- Validate on blur, not on every keystroke; the hint explains how to fix it.
- Paths are mono; everything else sans.
- Never a placeholder as the only label.
