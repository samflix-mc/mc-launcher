The separate sign-in window: 440×520, movable, minimizable and closable, never resizable, with the auth dialog on a frosted pane.

## Provide
- A window root with the stage (the server artwork or the fallback), `.hm-pane` over it (a full-window frosted sheet: `glass-dark-strong` + `blur-lg`), a `.hm-titlebar--dialog --glass` (brand + "Sign in"), then the small `.hm-wordmark--sm`, the AuthDialog content (step 1, 2 or 3) with its own glass turned off (the pane is the glass), and a footer line in `ink-3`.
- Tauri window options: `width: 440, height: 520, resizable: false, maximizable: false, minimizable: true, decorations: false, center: true`.

## Rules
- The pane is the only glass: no inner card, no double blur. The artwork glows through as colour, not detail.
- Closing this window with no stored session quits the launcher: warn in the footer ("Closing this window quits Helm") only after the player has hovered the close button once.
- The window is also reused for "Switch account" from the player menu, with the main window blurred behind a `.hm-scrim`.
