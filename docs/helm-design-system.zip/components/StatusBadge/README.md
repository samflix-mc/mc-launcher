A pill with a coloured dot, a word and an optional value: the server, modpack and account states on Spawn and in the titlebar.

## Provide
- `.hm-status` + one of `--online`, `--offline`, `--maintenance`, `--update`, `--warning`, `--unknown`; `.hm-status__dot`, the label text, and optionally `.hm-status__value` (players, version, time).
- `--lg` (36px) for the two headline badges on Spawn.

## Rules
- The word is mandatory. The dot colour alone is never the message: `success` and `danger` differ by hue only and a colour-blind player sees the same dot.
- Text stays `ink`; only the dot and the soft tint change. Do not colour the label.
- `--unknown` pulses until the first poll answers; after a failed poll switch to `--offline` with the value "no answer".
- `--update` uses the accent because it is a call to action (the play button will say the same).
