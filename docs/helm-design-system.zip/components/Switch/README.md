An on/off control for boolean settings, 40×24, gold when on.

## Provide
- `<input type="checkbox" class="hm-switch" role="switch">` with a visible label (a `.hm-setting__label` or a `<label>` around it); `checked`, `disabled`.

## Rules
- Label the thing that is on, positively: "Hide launcher while playing", not "Don't keep the launcher open".
- A switch applies immediately; if the change needs a Save, use a checkbox in a form instead.
- Disabled + on means required (verify files): say so in the description.
