The 360×480 portrait, undecorated window shown while the launcher loads its manifest, the session and the update check; it cannot be closed while loading and becomes the error screen, closable, if the network is missing.

## Provide
- `.hm-splash` filling the window (`bg-raised`, a faint gold glow, no artwork): the `.hm-wordmark` (pixel face, uppercase, with the gold `.hm-wordmark__dot`), an `.hm-progress--lg` 220px wide, and `.hm-splash__status` (spinner + the current step in `caption`). `.hm-splash__footer` holds the version at the left and the server slug at the right, in the mono face.
- Loading: no titlebar and no controls at all — the window cannot be moved, shrunk or closed; the launcher closes it itself when the next window is up.
- Steps, in order, each a status line: Checking for launcher updates → Fetching server manifest → Restoring session → Checking modpack. Then either the main window (session found) or the sign-in window (none).
- Error: a `.hm-titlebar--dialog` with only the close button appears (closing quits the launcher); the progress and status are swapped for an `.hm-alert--danger` (title "Can't reach the server", a Try again primary), the countdown as the status line ("Retrying in 12 s") and the error code in the footer in mono.

## Rules
- Portrait on purpose, like a game client's loader: the wordmark sits in the upper half, the progress under it, the footer pinned.
- The splash never shows the artwork: it must open instantly, before anything is downloaded.
- Auto-retry with a visible countdown (footer: "3/5"); the Try again button resets the counter. After five failures the countdown stops and only the button and the close control remain. No offline mode: the launcher exists to join one server.
- Tauri: `width: 360, height: 480, decorations: false, resizable: false, closable: false` at start, `setClosable(true)` on the error state; `center: true`, `alwaysOnTop: false`; close it once the next window is shown, never before.
