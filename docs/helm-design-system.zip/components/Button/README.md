Buttons for everything except the play action: a light-glass secondary by default, a gold primary, a ghost, a danger and the white Microsoft sign-in.

## Provide
- `<button class="hm-btn">` plus one variant: `--primary` (gold gradient, `on-gold` text), `--ghost`, `--danger`, `--microsoft`.
- Sizes: `--sm` (28px) for inline actions in rows, cards and toasts, default 36px, `--lg` (44px) for the dialog's main action. `--block` fills its container, `--icon` makes a square icon-only button (give it `aria-label`).
- An icon: a 16px Lucide SVG with class `hm-btn__icon` before the label.
- Loading: set `aria-busy="true"`; the label hides and a spinner takes its place, width unchanged.

## Rules
- One primary per view. On Spawn the primary is the play button, so every `.hm-btn` there is secondary or ghost.
- `--microsoft` is white on purpose (Microsoft's "Sign in with Microsoft" button guidelines). Put Microsoft's official logo from their branding kit in the `hm-btn__slot` position (`<img>` 16px); the preview shows a neutral placeholder square until the asset is dropped into `assets/Logos`.
- `--danger` is for sign out, delete instance, reset settings; it turns solid `danger` on hover.
- Disabled buttons keep their label readable (`ink-3` on `glass`, 4.6:1); prefer disabling with a hint over hiding.
