The news section: the page title with the source site under it, a segmented filter, a featured tile, then a three-column tile grid that scrolls; every tile opens the item in the browser.

## Layout
- The nav (no badge once opened), a header row with the `display-lg` title "News" and a caption naming the source and its freshness ("corsair-isles.net · updated 2 min ago", `globe` icon) at the left, the `.hm-seg` filter (All / Updates / Events / Launcher, `aria-pressed`) at the right; then, in a `.hm-scroll` area, the `.hm-news--featured` tile and `.hm-news-grid` with the rest, newest first; the bottom bar keeps the player badge at the right and nothing in the centre.
- Items come from one JSON file the server publishes (its URL is in the server manifest), fetched on the splash and refreshed when the section opens; the launcher caches the last copy and the images. The file carries everything a tile shows:

```json
{
  "site": "https://corsair-isles.net",
  "updated": "2026-09-12T18:00:00Z",
  "items": [
    { "id": "modpack-1-4-2", "title": "Modpack 1.4.2 is live", "date": "2026-09-12",
      "tags": ["update"], "pinned": true,
      "image": "https://corsair-isles.net/news/1-4-2/cover.jpg",
      "excerpt": "Cannons, cargo holds and a rebuilt harbour…",
      "url": "https://corsair-isles.net/news/modpack-1-4-2" }
  ]
}
```

  `title`, `date`, `url` are required; `tags` picks the tag style (`update` → info, `event` → success, `incident` → danger, anything else neutral); `image` is 16:9, 800×450 or larger, or absent (placeholder gradient); `excerpt` shows only on the featured and pinned tiles; at most one `pinned`. `site` feeds the caption under the title, `updated` its freshness. Opening a tile opens `url` in the default browser — nothing is rendered in the launcher beyond the tile.

## Rules
- The featured slot shows the pinned item, else the newest; it also appears in the grid in date order so the list stays complete.
- Filters narrow the grid only; the featured tile stays. Categories come from the tags (update, event, build, launcher); unknown tags render neutral.
- Loading: a featured placeholder and three `--ph` tiles with no text, then a spinner in the footer while more pages load. Empty: one `.hm-alert--info` "No news yet".
- Nothing else lives on this page: no comments, no reactions, no in-app reader.
