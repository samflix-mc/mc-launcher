The 40px bar at the top of every frameless window: a drag region, the launcher name in the pixel face, an optional window title, the notification bell, and the window controls at the right.

## Provide
- The element `.hm-titlebar` with `data-tauri-drag-region` (Tauri) — the whole bar drags the window; `.hm-titlebar__tools` and `.hm-winctl` are `no-drag`.
- `.hm-titlebar__brand` = the launcher name (pixel face, uppercase); after `.hm-titlebar__sep`, the current server or dialog name in `caption` weight.
- `.hm-titlebar__tools` before the controls, holding the `.hm-bell` button (16px `bell` icon, `aria-expanded`, a gold `.hm-bell__count` with the unread count, hidden at zero); it opens the NotificationCenter panel.
- Three `.hm-winctl__btn` buttons with `aria-label`s Minimize / Maximize / Close, each holding a 12px icon (`minus`, `square`, `x` from `assets/Icons`); the close button carries `--close` (hover turns `danger` with `ink-inverse`).
- Wire each to `getCurrentWindow().minimize()` / `toggleMaximize()` / `close()`.

## Variants
- Default: transparent, floats over the stage, so the artwork runs under it.
- `.hm-titlebar--glass`: translucent base with `blur-lg` and a bottom hairline — the auth window and any window without artwork.
- `.hm-titlebar--dialog`: hides the maximize button. Pair it with Tauri `resizable: false, maximizable: false` on that window: the button hides, the OS rule enforces it. The splash shows no titlebar while loading and a close-only one on its error state (see SplashScreen).

## Do / don't
- Do keep 46px-wide hit areas: they match Windows' own caption buttons; the bell is 32px because it is not a caption button.
- Don't put anything interactive in the drag region without `-webkit-app-region: no-drag` (`.hm-btn`, `.hm-nav`, `.hm-player`, `.hm-bell` already set it).
- Don't draw a titlebar on macOS if you use `titleBarStyle: Overlay`; keep the drag region and the bell, hide `.hm-winctl` there.
