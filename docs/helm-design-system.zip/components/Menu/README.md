An opaque menu on `bg-overlay` for the few places that need one: the player badge menu and any context menu.

## Provide
- `.hm-menu` with `.hm-menu__label` (an uppercase caption for the section), `.hm-menu__item` buttons (16px icon + label), `.hm-menu__sep` between groups; `--danger` on a destructive item.
- Position it with the CDK overlay (Angular) above or below its trigger, 8px away; close on outside click and Escape; return focus to the trigger.

## Rules
- Opaque on purpose (`bg-overlay`, `shadow-menu`, no blur): a menu must read over any artwork and any glass.
- Verbs, sentence case, no trailing colons. Destructive last, after a separator.
