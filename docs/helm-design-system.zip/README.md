Helm is the shell of a Minecraft server launcher: a frameless Tauri window, an Angular front end, and a dark glass interface that lets each server's own artwork show through. The system is server-agnostic on purpose — the pirate server is the first tenant, not the brand — so nothing here is nautical except the compass icon on Spawn. Three windows (splash, sign-in, main), three sections (Spawn, News, Settings), one accent.

## Identity

- The name is set in plain type: `display-xl` (Pixelify Sans, uppercase) followed by the gold `.hm-wordmark__dot`. There is no drawn logo; when one exists, it replaces the wordmark on the splash and the sign-in window and goes under `assets/Logos`.
- "Helm" is a working name. Replacing it means: the wordmark text, `hm-titlebar__brand`, `tokens.json` `name`, and the tagline on the cover — nothing in the CSS.
- The pixel face is the only Minecraft reference in the type. It appears in exactly four places: the wordmark, page titles (`display-lg`), panel titles (`display-md`) and the pinned card's title. Everything else is Manrope.

## Content

- English UI, sentence case everywhere, no title case, no exclamation marks, no emoji. Buttons are verbs ("Install", "Play", "Try again"); status badges are states ("Online", "Up to date"); hints are facts ("This machine has 16 GB").
- Address the player as "you"; call the software "Helm" (or the launcher's real name), never "we".
- Errors: what happened, then what to do, two short sentences. "Can't reach the server. Check your network, then try again."
- Numbers: tabular figures in the mono face for anything that updates (percent, MB/s, timers, ping); "6 GB" not "6144 MB"; dates as "Sep 12, 2026".
- Minecraft terms as Mojang writes them: Minecraft, Java Edition, modpack (one word), Forge, the player's profile name (never "username").

## Colour

- Grounds: the window is `bg`; the splash and windows without artwork are `bg-raised`; menus and tooltips are opaque `bg-overlay`. The server artwork sits on `.hm-stage__art` under a vertical `scrim` gradient (52% at the top, 36% mid, 80% at the bottom) so the bottom bar always reads and the middle shows the picture.
- Glass is a composition, not a colour — five layers in `.hm-glass`: the `glass-dark` base (bg at 46%; `glass-dark-strong`, 62%, for dialogs, toasts and the notification panel), a diagonal white face, a specular in the top-left, a 1px rim gradient from `glass-sheen` to `glass-line` that catches light again at the bottom-right, and `blur-md` with `glass-saturate` behind it, under one `shadow-glass`. It only reads as glass over the artwork: give every window a stage. Controls on top of a panel use light glass (`glass` + an inset catch-light) instead of stacking dark glass. Details and the bright-artwork knob: the Glass guidelines.
- Text: `ink` for content, `ink-2` for descriptions and metadata, `ink-3` for placeholders and footers, never lighter. All three hold 4.5:1 on every ground including glass over a dimmed artwork; `ink-3` never below 12px.
- The accent is gold: `gold` for links, focus, active icons, the progress fill, the unread count and the update badge dot; the `gold-bright → gold → gold-deep` gradient for primary fills with `on-gold` text; `gold-soft` and `gold-line` for the one selected or pinned thing on a page. No other saturated fill exists; a page has at most one gold-filled control (the play button on Spawn, the primary in a dialog).
- Statuses: `success` online / up to date / done, `danger` offline / failed / destructive, `info` maintenance / notices, `warning` advisory only (memory, disk). As text only on `bg`, `glass` and `glass-strong`; as a badge, the colour is the dot and the `-soft` tint while the label stays `ink`. A word or an icon always accompanies the colour: success and danger are told apart by hue only.
- Keyboard focus is `focus-ring` (gold), 2px solid with a 2px offset on every surface; on a gold fill the ring is `ink`.
- The Microsoft sign-in button is `microsoft` (white) with `ink-inverse` text, following Microsoft's button guidelines; drop their official logo from the "Sign in with Microsoft" branding kit into `assets/Logos` and place it in the button's slot — the system does not draw it.

## Type

- Families: `pixel` (Pixelify Sans, hosted by Google Fonts), `sans` (Manrope), `mono` (JetBrains Mono). Load the three with one Google Fonts link in `index.html`; there are no font files in the system.
- Scale: `display-xl` 48 (wordmark), `display-lg` 32 (page titles), `display-md` 22 (panel and pinned titles); `title` 20/700 (dialogs), `heading` 16/600 (groups, cards, the player name), `body` 14 and `body-strong`, `caption` 12/500, `label` 11/700 uppercase +0.08em (tags, eyebrows), `button` 14/600 and `button-lg` 18/700 (the play button); `code` 13 (paths, logs, versions) and `code-lg` 26 (the device code).
- Pixelify Sans is set at weight 500 and never below 22px: at small sizes it becomes a texture. Manrope carries every label; do not use the pixel face in buttons, badges or body copy.
- Line lengths: 60–70 characters in cards and dialogs; the settings descriptions are one line.

## Spacing, radius, elevation

- A 4px scale, `space-1` … `space-16`. Panels pad `space-5`, cards `space-4`, rows `space-4` vertical and `space-5` horizontal, page gutters `space-6`, the titlebar is `space-10` tall.
- Radii by size: `radius-sm` 6 (chips, code wells), `radius-md` 10 (controls), `radius-lg` 16 (cards, panels), `radius-xl` 24 (dialogs, the play button, the pinned card), `radius-window` 12 on the frameless window, `radius-pill` for pills.
- Depth comes from blur and one shadow, not from stacking: `shadow-glass` on panels, `shadow-window` on windows, `shadow-control` on buttons, `shadow-gold` only on the play button and the hovered primary, `shadow-menu` on opaque menus. Never two shadows on one element beyond what a token already composes.
- Blur: `blur-sm` (12) for pills and badges, `blur-md` (24) for panels, `blur-lg` (40) for the titlebar, dialogs, toasts, the play well and the sign-in pane. Every backdrop-filter pairs its blur with `saturate(glass-saturate)`.

## Motion

- Durations `--motion-fast` 120ms (hover, colour), `--motion-base` 200ms (switches, nav, lifts), `--motion-slow` 360ms (progress width); easings `--ease-out` for everything and `--ease-spring` for the play button and switch knob. Defined in `bundle.css`, not as tokens.
- Only opacity, transform, background, border and width animate; nothing moves on the page except a 1–2px lift on hover, a news tile's picture zooming 3% under the cursor, and a toast sliding up 12px as it appears. Spinners rotate at 0.8s; the indeterminate bar slides at 1.4s.
- `prefers-reduced-motion` drops transitions and slows animations to 1.5s; honour it in Angular animations too.

## Layout

- Three windows, all `decorations: false` in Tauri, corners `radius-window`: the splash 360×480, portrait (no controls while loading; close only on its network error), the sign-in window 440×520 (minimize and close, not resizable; a `.hm-pane` frosted sheet over the artwork), the main window 1024×640 minimum, resizable. Each begins with `.hm-titlebar` as the drag region; the main window's titlebar carries the notification bell.
- The main window: `.hm-stage` (artwork + scrim) under `.hm-page`, whose three rows are the centred `.hm-nav`, the section content, and the bottom bar (`.hm-playbar` centre, `.hm-player` right). Spawn keeps its middle empty so the artwork shows; News is a featured tile and a tile grid that scroll above the bottom bar, every tile opening its item in the browser; Settings drops the bottom bar. Toasts stack in the bottom-left corner; the notification panel hangs under the bell at the top-right.
- Artwork is per server (`background-image` from the server manifest, cached on disk); `.hm-stage__art--fallback` draws an abstract warm/cool gradient when there is none or it has not loaded. The default, until a server ships its own, is Mojang's "Wilderness Bound" key art in `assets/Artwork`; news items are tiles built on 16:9 images from the server's website feed (`assets/Demo` holds picsum.photos stand-ins for the previews) and open on that website in the browser.
- Minimum touch/click target 28px (`--sm` buttons), default 36px; window controls 46×40.

## States and feedback

- Loading: a spinner beside a sentence for under ~2 s; a progress bar with a step name and a value for anything longer; the play button itself shows install progress.
- Empty: one `info` alert or a single sentence in `ink-2`; never an illustration.
- Errors: an `.hm-alert--danger` with a title, one line of guidance and a primary Try again. Network loss on the splash shows the alert with an auto-retry countdown; in the main window it turns the play and install buttons `--disabled` with the countdown in the hint. There is no offline mode: the launcher exists to join one server.
- Notifications, three tiers with one vocabulary: a toast (`.hm-toast`, bottom-left, transient) for a job that finished or failed and for session and server events; the notification center (`.hm-notif`, under the bell, persistent, last 50) that keeps every toast; the OS notification (`@tauri-apps/plugin-notification`) for the same events while the launcher is hidden behind the game. The setting "Notifications" picks Launcher and system / Launcher only / Off. Details: the Toast and NotificationCenter guidelines.

## Iconography

- Icons are Lucide (`lucide-angular`, ISC): `assets/Icons` holds the 44 the launcher uses as single-ink SVG in `ink`; inline them or use the library so they take `currentColor`. 20px in text and nav, 16px in buttons and rows, 12px in window controls, stroke 1.75–2. No filled icons, no emoji, no coloured icons except the Microsoft logo asset you add yourself.
- The player's head is an image, not an icon: a 3D head render by UUID from a skin render service, 40px, `image-rendering: pixelated`, with the neutral cube placeholder until it loads.

## Consuming from Angular (Tauri)

- Add `tokens.css` then `components/bundle.css` to `angular.json` `styles` (in that order) and set `<html data-theme="dark">`; add the Google Fonts link for Manrope, Pixelify Sans and JetBrains Mono in `index.html`.
- Components are classes: wrap them in Angular components that expose inputs for the modifiers (`<hm-button variant="primary" size="lg">` renders `<button class="hm-btn hm-btn--primary hm-btn--lg">`). Bind progress with `[style.--p]="pct + '%'"`; bind states with `[class.hm-play--busy]`, `[attr.aria-current]`, `[attr.aria-busy]`.
- Tauri: put `data-tauri-drag-region` on `.hm-titlebar`; the window controls call `getCurrentWindow()`; open the sign-in flow in its own `WebviewWindow` with the AuthWindow options; enable `transparent` only if you want the OS to draw rounded corners under `radius-window` (otherwise keep the window opaque and let `.hm-window` clip).
- WebView2 (Windows) and WKWebView (macOS) both support `backdrop-filter` and `color-mix()`; on Linux WebKitGTK, blur may be disabled by the compositor — the `glass-dark` base keeps everything legible without it.
