The stage artwork behind the main window and the sign-in window. One file for now: Mojang's "Wilderness Bound" Minecraft key art (2560×932, public on minecraft.net), used as the default until each server ships its own picture in its manifest.

- Set it as `background-image` on `.hm-stage__art` (`background-size: cover; background-position: center`); the stage's scrim gradient (bg 52% / 36% / 80%, top to bottom) and every glass panel's base sit on top, so the picture reads as light and colour, sharpest in the empty middle of Spawn.
- Choose artwork with a mid-to-dark average and no text: the panels are legible over this reference (`#4a4a4a` average) and brighter; over a very bright picture raise `--glass-base` to bg at 60% on the window root.
- Cache the file on disk next to the modpack; the fallback gradient (`.hm-stage__art--fallback`) covers the first launch and a missing image.
- Mojang's asset usage guidelines apply to the key art; a server using its own art replaces this file.
