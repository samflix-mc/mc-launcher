Stand-in photographs for news cards in the previews, from picsum.photos (seeded so they stay the same: `https://picsum.photos/seed/<seed>/800/450.jpg`, seeds harbour, regatta, shipwright, launcher, lighthouse). They show how a 16:9 image sits in `.hm-news__media` and under the pinned card; they are not part of the launcher.

- Real news images come from the server manifest at 800×450 or larger, JPEG or WebP; the launcher caches them.
- A card without an image gets `.hm-news__media--ph`, the gradient placeholder — never a stock photo.
